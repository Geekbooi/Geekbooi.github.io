function myDate() {
    return Date();
};
exports.myDate = myDate;